import urlparse
from pplayer import PLPlayer
if __name__ == "__main__":
	args = urlparse.parse_qs(sys.argv[2][1:])
	PLPlayer(sys.argv[0], int(sys.argv[1])).run(args)
